/**
 * Created by joey on 8/7/14.
 */

exports.DB = 'mongodb://moral:DfvszXKePFtfB9KM@localhost:27017/moral';

