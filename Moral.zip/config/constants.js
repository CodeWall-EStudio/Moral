/**
 * Created by joey on 8/9/14.
 */

exports.CAS_URI = 'http://dand.71xiaoxue.com/sso.web';

exports.CAS_USER_INFO_CGI = 'http://mapp.71xiaoxue.com/components/getUserInfo.htm';

/*msg : {
    0 : '操作成功!',
        101 : '出错啦',
        1001 : '您还没有登录!',
        1004 : '没有找到资源!',
        1010 : '您没有查看该资源的权限!',
        1011 : '参数出错啦!',
        1013 : '出错啦',
        1014 : '同名啦,请修改名称!',
}*/

exports.MSG_SUCC = 0;
exports.MSG_ERR = 101;
exports.MSG_GUEST = 1001;
exports.MSG_AUTH = 1010;
exports.MSG_PARAM = 1011;
