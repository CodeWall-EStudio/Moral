;(function(){
    angular.module('teacherLogin', [
        'dy.controllers.loginSSO'
    ]);
})();