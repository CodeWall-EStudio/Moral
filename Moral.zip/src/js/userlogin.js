(function(){
    angular.module('userLogin', [
        'dy.controllers.loginUin'
    ]);

})();