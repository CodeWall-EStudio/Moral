;(function(){
    angular.module('student', [
        'dy.controllers.mgradelist', //年级列表
        'dy.controllers.msg',
        'dy.controllers.student', //学生
        'dy.controllers.indexnav', //导航条
        'dy.controllers.quota'//指标
    ]);
})();